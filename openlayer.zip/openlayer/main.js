import 'regenerator-runtime/runtime'
import 'ol/ol.css';
import Feature from 'ol/Feature';
import Map from 'ol/Map';
import View from 'ol/View';
import {Circle as CircleStyle, Fill, Stroke, Style, Icon} from 'ol/style';
import {Modify, Snap, Pointer as PointerInteraction, defaults as defaultInteractions} from 'ol/interaction';
import {OSM, Vector as VectorSource} from 'ol/source';
import {Tile as TileLayer, Vector as VectorLayer} from 'ol/layer';
import {get} from 'ol/proj';
import ImageLayer from 'ol/layer/Image';
import Projection from 'ol/proj/Projection';
import Static from 'ol/source/ImageStatic';
import {getCenter} from 'ol/extent';
import Draw, {
  createBox,
} from 'ol/interaction/Draw';
import {LineString, Point, Polygon} from 'ol/geom';


// Map views always need a projection.  Here we just want to map image
// coordinates directly to map coordinates, so we create a projection that uses
// the image extent in pixels.
const extent = [0, 0, 1024, 968];
const projection = new Projection({
  code: 'xkcd-image',
  units: 'pixels',
  extent: extent,
});

const raster = new ImageLayer({
      source: new Static({
        attributions: '� <a href="https://xkcd.com/license.html">xkcd</a>',
        url: 'http://localhost:1234/3abce8b8ab8e4cd7d509f9bb4812fa61.jpg',
        projection: projection,
        imageExtent: extent,
      }),
    });
	
class Drag extends PointerInteraction {
  constructor() {
    super({
      handleDownEvent: handleDownEvent,
      handleDragEvent: handleDragEvent,
      handleMoveEvent: handleMoveEvent,
      handleUpEvent: handleUpEvent,
    });

    /**
     * @type {import("../src/ol/coordinate.js").Coordinate}
     * @private
     */
    this.coordinate_ = null;

    /**
     * @type {string|undefined}
     * @private
     */
    this.cursor_ = 'pointer';

    /**
     * @type {Feature}
     * @private
     */
    this.feature_ = null;

    /**
     * @type {string|undefined}
     * @private
     */
    this.previousCursor_ = undefined;
  }
}

/**
 * @param {import("../src/ol/MapBrowserEvent.js").default} evt Map browser event.
 * @return {boolean} `true` to start the drag sequence.
 */
function handleDownEvent(evt) {
  const map = evt.map;

  const feature = map.forEachFeatureAtPixel(evt.pixel, function (feature) {
    return feature;
  });

  if (feature) {
    this.coordinate_ = evt.coordinate;
    this.feature_ = feature;
  }

  return !!feature;
}

/**
 * @param {import("../src/ol/MapBrowserEvent.js").default} evt Map browser event.
 */
function handleDragEvent(evt) {
  const deltaX = evt.coordinate[0] - this.coordinate_[0];
  const deltaY = evt.coordinate[1] - this.coordinate_[1];

  const geometry = this.feature_.getGeometry();
  geometry.translate(deltaX, deltaY);

  this.coordinate_[0] = evt.coordinate[0];
  this.coordinate_[1] = evt.coordinate[1];
}

/**
 * @param {import("../src/ol/MapBrowserEvent.js").default} evt Event.
 */
function handleMoveEvent(evt) {
  if (this.cursor_) {
    const map = evt.map;
    const feature = map.forEachFeatureAtPixel(evt.pixel, function (feature) {
      return feature;
    });
    const element = evt.map.getTargetElement();
    if (feature) {
      if (element.style.cursor != this.cursor_) {
        this.previousCursor_ = element.style.cursor;
        element.style.cursor = this.cursor_;
      }
    } else if (this.previousCursor_ !== undefined) {
      element.style.cursor = this.previousCursor_;
      this.previousCursor_ = undefined;
    }
  }
}

/**
 * @return {boolean} `false` to stop the drag sequence.
 */
function handleUpEvent() {
  this.coordinate_ = null;
  this.feature_ = null;
  return false;
}
	
const pointFeature = new Feature(new Point([0, 0]));

const polygonFeature = new Feature(
  new Polygon([
    [
      [-3e6, -1e6],
      [-3e6, 1e6],
      [-1e6, 1e6],
      [-1e6, -1e6],
      [-3e6, -1e6],
    ],
  ])
);

const source = new VectorSource({
        features: [pointFeature, polygonFeature],
      });
const vector = new VectorLayer({
  source: source,
  style: new Style({
    fill: new Fill({
      color: 'rgba(255, 255, 255, 0.2)',
    }),
    stroke: new Stroke({
      color: '#C54141',
      width: 5,
    }),
    image: new Icon({
	  anchor: [0.5, 46],
	  anchorXUnits: 'fraction',
	  anchorYUnits: 'pixels',
	  opacity: 0.95,
	  scale: 0.15,
	  src: 'download.png',
	}),
  }),
});


const map = new Map({
  interactions: defaultInteractions().extend([new Drag()]),
  layers: [raster, vector],
  target: 'map',
  view: new View({
    projection: projection,
    center: getCenter(extent),
    zoom: 2,
    maxZoom: 8,
  }),
});


let draw, snap; // global so we can remove them later
const typeSelect = document.getElementById('type');
const modeSelect = document.getElementById('mode');

function addInteractions() {
  let value = typeSelect.value;
  let geometryFunction;
  if (value === 'Box') {
	  value = 'Circle';
	  geometryFunction = createBox();
	  
	  draw = new Draw({
		source: source,
		type: value,
		geometryFunction: geometryFunction,
	  });
	} else {
	  draw = new Draw({
		source: source,
		type: value,
	  });
	}

  
  map.addInteraction(draw);
  snap = new Snap({source: source});
  map.addInteraction(snap);
}

/**
 * Handle change event.
 */
typeSelect.onchange = function () {
  map.removeInteraction(draw);
  map.removeInteraction(snap);
  addInteractions();
};

/**
 * Handle change event.
 */
modeSelect.onchange = function () {

  map.removeInteraction(draw);
  map.removeInteraction(snap);

  let value = modeSelect.value;
  if (value === 'Add') {
	addInteractions();
  }
  
};

addInteractions();
